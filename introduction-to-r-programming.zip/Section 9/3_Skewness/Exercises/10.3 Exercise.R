# Load the two data sets into R: "skew_1.csv", and "skew_2.csv".

# Identify the skew of the data sets, both visually, and numerically. 

# Try to interpret what you are seeing.