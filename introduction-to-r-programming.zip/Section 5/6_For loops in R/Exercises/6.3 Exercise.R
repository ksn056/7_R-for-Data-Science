

# Write a for loop that sums all the numbers from 1 to n 

