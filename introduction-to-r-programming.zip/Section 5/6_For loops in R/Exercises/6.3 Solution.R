

# Write a for loop that sums all the numbers from 1 to n 

n <- 10
sum <- 0

for(i in 1:n){
  sum <- sum + i
  print(sum)
} 

