


### Load the libraries you will need 

### Load the data as a tibble (readr has a function that does this directly)

### Get the descriptives for your data so you can understand what you're dealing with a little better

### Explore the data and see if there are any interesting trends to consider

### Define the linear model 

### Plot the regression line

### Print the results of the model

### How many observations was the regression run on?

### What is the R-squared of this regression? What does it tell you?

### Determine if size is a statistically significant predictor of price. 

### What is the regression equation associated with this regression model?


