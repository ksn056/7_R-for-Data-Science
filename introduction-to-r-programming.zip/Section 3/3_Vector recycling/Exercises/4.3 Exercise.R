# Imagine that you are working for the Ghostbusters, and for safety reasons you are recording the height and weight for everyone or everything the team encounters. So far you have collected information about the following. entities: Dr Peter Venkman, Dr Raymond Stantz, Dr. Eagon Spengler, Dana Barrett, Vigo, Slimer, and the Marshmallow Man.

# Create the following two vectors:
  
# A vector called weight, storing the values: 71, 67, 83, 67

# A vector called height, storing the values: 1.75, 1.81, 1.78, 1.82, 1.97, 2.12, 2.75

# You need to calculate the BMI for all you have data for. BMI is calculated by dividing the weight in kg by the height in meters squared.

# Carry out the operation and save the result in a variable called bmi.  

# What is your output?
  
# Try printing your bmi variable.

# Can you explain how you got the last three values, given that your weight variable only had 4 elements?