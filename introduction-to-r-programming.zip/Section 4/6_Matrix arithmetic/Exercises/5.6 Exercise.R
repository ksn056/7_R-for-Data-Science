# Lookup the runif() function. Create a 3x4 matrix with 12 random numbers generated using the runif() function; have the matrix be filled our row-by-row, instead of column-by-column.

# Name the columns of the matrix uno, dos, tres, cuatro, and the rows x, y, z.

# Scale the matrix by 10 and save the result.

# Extract a 2x4 matrix from it and save the result.

# Subtract the smaller matrix from the larger one. Can you do that? Why?
  
# Extract a 3x3 matrix from the original matrix and save the result. Try the subtraction again. Can you do that? Why?

# Extract the column called "uno" as a vector from the original matrix and save the result. Try the subtraction again. Can you do that? Why?
  
# Lookup the rnorm() function. Create a new 3x4 matrix with 12 random values generated using the rnorm() function.

# Perform matrix multiplication (using the * sign). Can you do that? How is the operation carried out?
  
# Perform inner matrix multiplication with the two matrixes. Can you do that? Why? Can you think of something to do to make this possible?