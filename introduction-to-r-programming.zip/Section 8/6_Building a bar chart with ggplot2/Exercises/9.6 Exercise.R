# Create a bar chart representation of the number of employees in the different positions in the employees data by gender.

# Set the theme to fivethirtyeight.

# Add plot title "Job positions by gender", and axes titles: "Job position", and "Employee count". Can you do that?
  
# Try setting the theme to something different and give it another go.

# Look up the scale_fill_manual() and scale_color_manual() functions. Try setting custom colors to your plot.

# Try to change the position on the canvas the legend is in. Use the theme() function to do that.

# Try to reverse the aesthetic mappings. Does this graph give you a better idea of your data? Is it easier to read? (Shouldn't be ????)